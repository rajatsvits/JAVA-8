package com.pluralsight;

/**
 * Created by kevinj.
 */

public class Vehicle{}
