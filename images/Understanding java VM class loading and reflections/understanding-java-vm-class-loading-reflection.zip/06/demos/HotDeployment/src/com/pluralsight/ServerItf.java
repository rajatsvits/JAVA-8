package com.pluralsight;

public interface ServerItf {

    public String getQuote();
    
}