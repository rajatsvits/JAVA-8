package com.pluralsight;

public class ServerImpl implements ServerItf {
    @Override
    public String getQuote() {
        return "One small step for man";
    }
}
