package com.mantiso;

/**
 * Created by kevinj.
 */
public interface Drivable {
    void drive();
}
