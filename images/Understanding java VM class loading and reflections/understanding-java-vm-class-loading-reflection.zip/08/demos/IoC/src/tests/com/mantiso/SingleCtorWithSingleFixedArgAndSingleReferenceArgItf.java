package com.mantiso;

public interface SingleCtorWithSingleFixedArgAndSingleReferenceArgItf {
    String getValue();

    void setValue(String value);

    Logger getLogger();

    void setLogger(Logger logger);
}
