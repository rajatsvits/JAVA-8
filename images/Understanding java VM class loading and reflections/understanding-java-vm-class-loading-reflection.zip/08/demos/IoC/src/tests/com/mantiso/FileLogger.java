package com.mantiso;

/**
 * Created by kevinj.
 */
public class FileLogger implements Logger {
    public FileLogger(String fileName) {

    }
}
