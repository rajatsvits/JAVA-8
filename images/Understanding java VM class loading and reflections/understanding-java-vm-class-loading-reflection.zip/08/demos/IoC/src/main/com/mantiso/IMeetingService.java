package com.mantiso;

/**
 * Created by kevinj.
 */
public interface IMeetingService {
    String[] getAttendees();
}

