package com.mantiso;

/**
 * Created by kevinj.
 */
public interface IMeeting {
    String[] getAttendees();

    void setAttendees(String[] attendees);

    void getMeeting();
}
