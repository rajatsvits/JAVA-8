package com.pluralsight;

/**
 * Created by kevinj.
 */
public interface ICamera {
    public void takePhoto();
}
