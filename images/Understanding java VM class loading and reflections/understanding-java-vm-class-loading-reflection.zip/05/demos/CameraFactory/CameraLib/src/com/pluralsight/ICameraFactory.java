package com.pluralsight;

/**
 * Created by kevinj.
 */
public interface ICameraFactory {
    public ICamera createCamera();
}
