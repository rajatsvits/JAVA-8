package com.pluralsight;

public interface IQuote{
    String getQuote();
}