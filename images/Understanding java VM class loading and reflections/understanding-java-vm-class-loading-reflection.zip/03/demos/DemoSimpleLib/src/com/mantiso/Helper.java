package com.mantiso;

public class Helper{
	public String getMessage() {
		return "Hello from helper";
	}
}