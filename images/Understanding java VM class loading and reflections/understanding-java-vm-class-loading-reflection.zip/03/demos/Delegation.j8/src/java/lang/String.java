package java.lang;

public class String {
	public int getValue() {return 42;}
}