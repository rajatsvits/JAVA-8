package com.pluralsight;

public class Main {
	public static void main(String[] args) {
		com.mantiso.Helper helper = new com.mantiso.Helper();
		System.out.println(helper.getMessage());
		String message = new String();

//		System.out.println(message.getValue());
	}
}